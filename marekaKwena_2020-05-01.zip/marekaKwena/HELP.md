# Getting Started

how run the application.
---------------------------

mvn clean install -DskipTests

Then, run spring

URLs to the load the UI page 
-----------------------------
http://localhost:8880

Which is planet_select.html

=========== Problems I have due to time-frame ====
I could use ReactJS if had more time. 
I could have created lots of tests
