package za.co.discovery.assignment.marekaKwena.repository;

import org.springframework.data.repository.CrudRepository;

import za.co.discovery.assignment.marekaKwena.entity.ShortestPath;

public interface ShortestDistancePathRepository extends CrudRepository<ShortestPath, Long> {
}
