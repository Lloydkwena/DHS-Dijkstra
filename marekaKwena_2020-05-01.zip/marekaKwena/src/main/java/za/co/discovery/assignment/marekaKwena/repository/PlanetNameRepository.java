package za.co.discovery.assignment.marekaKwena.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import za.co.discovery.assignment.marekaKwena.entity.PlanetNames;

@Repository
public interface PlanetNameRepository extends CrudRepository<PlanetNames, Long> {
}
