package za.co.discovery.assignment.marekaKwena.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import za.co.discovery.assignment.marekaKwena.entity.PlanetNames;
import za.co.discovery.assignment.marekaKwena.entity.ShortestPath;
import za.co.discovery.assignment.marekaKwena.repository.ShortestDistancePathRepository;
import za.co.discovery.assignment.marekaKwena.service.ShortestDistancePathService;

@Controller
public class ShortestPathController {
    @Autowired
    private ShortestDistancePathRepository shortestDistanceRepository;
    @Autowired
    private ShortestDistancePathService shortestPathService;
    @GetMapping("/")
    public String loadUIPage(Model model) {
        model.addAttribute("planetNames", new PlanetNames());
        return "planet_select";
    }
    @PostMapping("/planetPath")
    public String findshortestpath(Model model, @ModelAttribute PlanetNames planetNames) {
        ShortestPath shortestDistance = new ShortestPath();
        List<ShortestPath> listShortestDistance = (List<ShortestPath>)shortestDistanceRepository.findAll();
        listShortestDistance.forEach(l -> {
            if (l.getPlanetNode().equalsIgnoreCase(planetNames.getPlanetSourceName())) {
                shortestDistance.setPath(l.getPath());
            }
        });

        String shortestPath = shortestPathService.shortestPath(planetNames.getPlanetSourceName(), planetNames.getDestinationPlanetName());
        model.addAttribute("shortestPath", shortestPath);
        //explicit mapping for /error
        return "results";
    }
}
