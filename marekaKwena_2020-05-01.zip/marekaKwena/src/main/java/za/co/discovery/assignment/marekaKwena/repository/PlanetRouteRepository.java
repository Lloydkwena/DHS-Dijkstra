package za.co.discovery.assignment.marekaKwena.repository;

import za.co.discovery.assignment.marekaKwena.entity.*;

import org.springframework.data.repository.CrudRepository;


public interface PlanetRouteRepository extends CrudRepository<PlanetRoutes, Long>{

}
