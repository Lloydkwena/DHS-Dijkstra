package za.co.discovery.assignment.marekaKwena.controller;

import za.co.discovery.assignment.marekaKwena.entity.PlanetRoutes;
import za.co.discovery.assignment.marekaKwena.repository.PlanetRouteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

@RestController
@RequestMapping("/importFileSer")
public class ImportFileController {
    @Autowired
    PlanetRouteRepository shortestPathRepository;

    @RequestMapping(value = "/importFile", method = RequestMethod.GET)
    public void importFile() throws IOException {
        File file = new ClassPathResource("planetroutes.txt").getFile();
        try {
            BufferedReader b = new BufferedReader(new FileReader(file));
            String readLine = "";
            b.readLine();
            while ((readLine = b.readLine()) != null) {
                PlanetRoutes planetRoute = new PlanetRoutes();
                planetRoute.setId(Long.parseLong(readLine.substring(0, 4).trim()));
                planetRoute.setPlanetSource(readLine.substring(4, 8).trim());
                planetRoute.setPlanetDestination(readLine.substring(8, 12).trim());
                planetRoute.setDistance(Float.parseFloat(readLine.substring(12).trim()));
                shortestPathRepository.save(planetRoute);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
