package za.co.discovery.assignment.marekaKwena.appMain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import za.co.discovery.assignment.marekaKwena.entity.PlanetNames;
import za.co.discovery.assignment.marekaKwena.entity.PlanetRoutes;
import za.co.discovery.assignment.marekaKwena.repository.*;

/**************************************************************
 * String Events to read two resource text files.
 *      importPlanetNamesFile();
 *      importPlanetRouteFile();
 */
@SpringBootApplication(scanBasePackages = "za.co.discovery.*")
@EnableJpaRepositories("za.co.discovery.*")
@EntityScan( basePackages = {"za.co.discovery.*"} )
@EnableTransactionManagement
public class MarekaKwenaApplication implements ApplicationListener<ContextRefreshedEvent> {
    @Autowired
    PlanetRouteRepository shortestPathRepository;
    @Autowired
    PlanetNameRepository planetNameRepository;

    public static void main(String[] args) {
        SpringApplication.run(MarekaKwenaApplication.class, args);
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        try {
            importPlanetNamesFile();
            importPlanetRouteFile();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void importPlanetRouteFile() throws IOException {
        File file = new ClassPathResource("planetroutes.txt").getFile();
        try {
            BufferedReader b = new BufferedReader(new FileReader(file));
            String readLine = "";
            b.readLine();
            while ((readLine = b.readLine()) != null) {
                PlanetRoutes planetRoute = new PlanetRoutes();
                planetRoute.setId(Long.parseLong(readLine.substring(0, 4).trim()));
                planetRoute.setPlanetSource(readLine.substring(4, 8).trim());
                planetRoute.setPlanetDestination(readLine.substring(8, 12).trim());
                planetRoute.setDistance(Float.parseFloat(readLine.substring(12).trim()));
                shortestPathRepository.save(planetRoute);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void importPlanetNamesFile() throws IOException {
        File file = new ClassPathResource("planetnames.txt").getFile();
        try {
            BufferedReader b = new BufferedReader(new FileReader(file));
            String readLine = "";
            b.readLine();
            while ((readLine = b.readLine()) != null) {
                PlanetNames planetNames = new PlanetNames();
                planetNames.setPlanetNode(readLine.substring(0, 4).trim());
                planetNames.setPlanetSourceName(readLine.substring(4).trim());
                planetNameRepository.save(planetNames);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

